import type { Config, Context } from "@netlify/edge-functions";

// Rasooi - Fooding Made Easy
// Tiffin Service for Off-Campus Students (Law Gate, Green Valley, Hardaspur)
// WhatsApp: +91 97078 89516

const TIFFIN_PLANS = [
  {
    id: "sub-1time-veg",
    name: "1-Time Daily Pure Veg Monthly Plan",
    price: 2599,
    originalPrice: 3300,
    duration: "30 Days (Lunch OR Dinner - 1 Meal/Day)",
    perMeal: "₹86 / meal",
    diet: "veg",
    razorpayUrl: "https://rzp.io/rzp/ALIkEfoh",
    refundableDeposit: 1000,
    description: "Weekly: 2 Din Paneer (Wed & Sun) + 5 Din Market Fresh Seasonal Sabzis (Aloo Gobi, Bhindi, Mix Veg), Dal, 4 Ghee Phulkas, Rice, Salad & Sunday Sweet. Doorstep delivery to Law Gate, Green Valley & Hardaspur PGs."
  },
  {
    id: "sub-1time-nonveg",
    name: "1-Time Daily Non-Veg Delight Monthly Plan",
    price: 2999,
    originalPrice: 3900,
    duration: "30 Days (Lunch OR Dinner - 1 Meal/Day)",
    perMeal: "₹99 / meal",
    diet: "non-veg",
    razorpayUrl: "https://rzp.io/rzp/5T62orL",
    refundableDeposit: 1000,
    description: "Weekly: 3 Din Chicken, 1 Din Anda, 1 Din Fish ya Paneer, plus Pure Veg on other days. 4 phulkas, jeera rice & salad. Doorstep delivery to Law Gate, Green Valley & Hardaspur PGs."
  },
  {
    id: "sub-7days-veg",
    name: "7-Day Trial Tiffin Pass (Pure Veg)",
    price: 649,
    duration: "7 Days (Lunch OR Dinner)",
    diet: "veg"
  },
  {
    id: "sub-7days-nonveg",
    name: "7-Day Trial Tiffin Pass (Non-Veg)",
    price: 749,
    duration: "7 Days (Lunch OR Dinner)",
    diet: "non-veg"
  },
  {
    id: "sub-full-veg",
    name: "Full Board Pure Veg Monthly Pass",
    price: 4899,
    originalPrice: 6200,
    duration: "30 Days (Both Lunch & Dinner - 60 Meals)",
    perMeal: "₹81 / meal",
    diet: "veg",
    description: "Complete 2-meal daily pass with lunch & dinner delivery to Law Gate, Green Valley & Hardaspur."
  },
  {
    id: "sub-full-nonveg",
    name: "Full Board Non-Veg Club Monthly Pass",
    price: 5699,
    originalPrice: 7200,
    duration: "30 Days (Both Lunch & Dinner - 60 Meals)",
    perMeal: "₹94 / meal",
    diet: "non-veg",
    description: "Complete 2-meal daily pass with chicken, egg and paneer rotations delivered to your PG door."
  }
];

export default async (request: Request, context: Context) => {
  const url = new URL(request.url);
  const pathname = url.pathname.replace(/\/$/, "");

  const corsHeaders = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };

  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  // 1. Health Endpoint: /api/health
  if (pathname === "/api/health") {
    return new Response(
      JSON.stringify({
        status: "healthy",
        brand: "Rasooi",
        tagline: "Fooding Made Easy",
        whatsapp: "9707889516",
        service: "Rasooi Off-Campus Tiffin Hub Edge API",
        runtime: "Netlify Edge Functions (Deno)",
        timestamp: new Date().toISOString(),
        coverage: "Law Gate, Green Valley, Hardaspur & Nearby PGs (Not in LPU campus)",
        hubLocation: "Shop 14, Main Market, Law Gate, Phagwara, Punjab",
        refundableTiffinSecurityDeposit: 1000,
        firstTimeUserSecurityFee: "₹1,000 (100% Refundable Tiffin Container Deposit)",
        clientLocation: {
          city: context.geo?.city ?? "Phagwara / Local",
          country: context.geo?.country?.name ?? "India",
        },
      }),
      { status: 200, headers: corsHeaders }
    );
  }

  // 2. Menu & Plans Catalog Endpoint: /api/menu
  if (pathname === "/api/menu") {
    return new Response(
      JSON.stringify({
        success: true,
        brand: "Rasooi",
        tagline: "Fooding Made Easy",
        whatsapp: "+91 97078 89516",
        businessModel: "100% Monthly Subscription Only (No daily orders)",
        deliveryAreas: ["Law Gate", "Green Valley", "Hardaspur", "Maheru Village PGs"],
        monthlyPlans: TIFFIN_PLANS,
        deliverySlots: {
          lunch: ["12:30 PM - 1:30 PM", "1:30 PM - 2:30 PM"],
          dinner: ["8:00 PM - 9:00 PM"]
        }
      }),
      { status: 200, headers: corsHeaders }
    );
  }

  // 3. Orders Endpoint: GET /api/orders or POST /api/orders
  if (pathname === "/api/orders") {
    if (request.method === "GET") {
      return new Response(
        JSON.stringify({
          success: true,
          brand: "Rasooi",
          tagline: "Fooding Made Easy",
          whatsapp: "9707889516",
          sampleActiveOrders: [
            {
              id: "RASOOI-7821",
              location: "Law Gate - Khalsa Street PG, Room 204",
              plan: "1-Time Daily Pure Veg Monthly Plan (₹2,599) - Dinner",
              status: "Out for Doorstep Delivery",
              rider: "Sukhwinder (Rasooi Delivery Rider)"
            },
            {
              id: "RASOOI-6349",
              location: "Green Valley - Block B Flats, Flat 302",
              plan: "1-Time Daily Non-Veg Monthly Plan (₹2,999) - Dinner",
              status: "Packed in Insulated Thermal Box",
              rider: "Aman (Rasooi Delivery Team)"
            }
          ]
        }),
        { status: 200, headers: corsHeaders }
      );
    }

    if (request.method === "POST") {
      try {
        const body = await request.json();
        const orderId = body.id || `RASOOI-${Math.floor(1000 + Math.random() * 9000)}`;
        
        const newOrder = {
          id: orderId,
          createdAt: new Date().toISOString(),
          brand: "Rasooi",
          type: "tiffin",
          status: "Order Confirmed at Rasooi Law Gate Kitchen",
          customerName: body.customerName || "Student",
          phone: body.phone || "",
          location: body.location || "Law Gate / Green Valley PG",
          room: body.room || "",
          slot: body.slot || "Dinner (8:00 PM - 9:00 PM)",
          itemsSummary: body.itemsSummary || "1-Time Daily Tiffin Plan",
          total: body.total || 2599,
          paymentMethod: body.paymentMethod || "UPI Online",
          trackingUrl: `/api/orders/${orderId}`
        };

        return new Response(
          JSON.stringify({
            success: true,
            brand: "Rasooi",
            whatsapp: "9707889516",
            message: "Tiffin order registered successfully with Rasooi - Fooding Made Easy!",
            order: newOrder
          }),
          { status: 201, headers: corsHeaders }
        );
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : "Invalid JSON body";
        return new Response(
          JSON.stringify({ success: false, error: "Failed to parse order body", details: message }),
          { status: 400, headers: corsHeaders }
        );
      }
    }
  }

  // 4. Order Tracking: /api/orders/:id
  if (pathname.startsWith("/api/orders/")) {
    const orderId = pathname.replace("/api/orders/", "").toUpperCase();

    return new Response(
      JSON.stringify({
        success: true,
        brand: "Rasooi",
        tagline: "Fooding Made Easy",
        orderId,
        type: "tiffin",
        statusStage: 3,
        statusText: "Out for Doorstep Delivery",
        hub: "Rasooi Law Gate Central Kitchen",
        estimatedArrival: "Within 10-12 Mins",
        rider: {
          name: "Sukhwinder Singh",
          vehicle: "Rasooi Delivery Bike PB-08",
          hotline: "+91 97078 89516"
        }
      }),
      { status: 200, headers: corsHeaders }
    );
  }

  return new Response(
    JSON.stringify({
      error: "Endpoint not found",
      availableEndpoints: [
        "GET  /api/health",
        "GET  /api/menu",
        "GET  /api/orders",
        "POST /api/orders",
        "GET  /api/orders/:id"
      ]
    }),
    { status: 404, headers: corsHeaders }
  );
};

export const config: Config = {
  path: "/api/*"
};
