/**
 * Rasooi - Fooding Made Easy
 * Monthly Subscription Tiffin Controller
 * Dedicated for Law Gate, Green Valley, Hardaspur & Nearby PGs
 * WhatsApp: +91 97078 89516
 */

class AppController {
    constructor() {
        this.cart = this.loadCart();
        this.appliedCoupon = null;
        this.activeScheduleDay = 'monday';
        this.selectedSubscription = null;
        this.isFirstTimeUser = true;
    }

    init() {
        this.renderWeeklyMenu(this.activeScheduleDay);
        this.renderSubscriptions();
        this.renderReviews();
        this.renderFaqs();
        this.populateHostelDropdowns();
        this.updateCartUI();
        this.setupEventListeners();
    }

    // ==========================================
    // SUBSCRIPTION CART STORAGE
    // ==========================================
    loadCart() {
        try {
            const raw = localStorage.getItem('rasooi_subscription_cart');
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            return [];
        }
    }

    saveCart() {
        try {
            localStorage.setItem('rasooi_subscription_cart', JSON.stringify(this.cart));
        } catch (e) {
            console.error(e);
        }
    }

    addToCart(item) {
        // Since it's subscription-based, replace or add plan
        const existing = this.cart.find(i => i.id === item.id && i.variant === item.variant);
        if (existing) {
            existing.qty += (item.qty || 1);
        } else {
            this.cart.push({
                id: item.id,
                name: item.name,
                price: item.price,
                type: 'subscription',
                variant: item.variant || '',
                image: item.image || '',
                qty: item.qty || 1
            });
        }
        this.saveCart();
        this.updateCartUI();
        this.showToast(`Selected "${item.name}"! 🍲`);
    }

    removeFromCart(index) {
        if (index >= 0 && index < this.cart.length) {
            const removed = this.cart[index];
            this.cart.splice(index, 1);
            this.saveCart();
            this.updateCartUI();
            this.showToast(`Removed "${removed.name}" from bag`);
        }
    }

    updateCartQty(index, delta) {
        if (index >= 0 && index < this.cart.length) {
            this.cart[index].qty += delta;
            if (this.cart[index].qty <= 0) {
                this.cart.splice(index, 1);
            }
            this.saveCart();
            this.updateCartUI();
        }
    }

    clearCart() {
        this.cart = [];
        this.appliedCoupon = null;
        this.saveCart();
        this.updateCartUI();
    }

    getCartSubtotal() {
        return this.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    }

    getDiscountAmount() {
        const subtotal = this.getCartSubtotal();
        if (!this.appliedCoupon) return 0;
        if (this.appliedCoupon.flatDiscount) {
            return Math.min(this.appliedCoupon.flatDiscount, subtotal);
        }
        if (this.appliedCoupon.discountPercent) {
            return Math.round((subtotal * this.appliedCoupon.discountPercent) / 100);
        }
        return 0;
    }

    getSecurityFee() {
        if (this.cart.length === 0) return 0;
        return this.isFirstTimeUser ? (window.LPU_DATA.refundableTiffinSecurityDeposit || 1000) : 0;
    }

    toggleSecurityDeposit(checked) {
        this.isFirstTimeUser = Boolean(checked);
        this.updateCartUI();
    }

    getCartTotal() {
        const subtotal = this.getCartSubtotal();
        const discount = this.getDiscountAmount();
        const security = this.getSecurityFee();
        return Math.max(0, subtotal - discount + security);
    }

    updateCartUI() {
        const badgeEls = document.querySelectorAll('.cart-count-badge');
        const totalCount = this.cart.reduce((sum, i) => sum + i.qty, 0);
        badgeEls.forEach(el => {
            el.textContent = totalCount;
            el.classList.toggle('hidden', totalCount === 0);
        });

        // Floating mobile bar
        const mobileBar = document.getElementById('mobileCartBar');
        if (mobileBar) {
            if (totalCount > 0) {
                mobileBar.classList.remove('hidden');
                document.getElementById('mobileBarCount').textContent = `${totalCount} Plan Selected`;
                document.getElementById('mobileBarTotal').textContent = `₹${this.getCartTotal()}`;
            } else {
                mobileBar.classList.add('hidden');
            }
        }

        // Render Cart Drawer Content
        const cartItemsContainer = document.getElementById('cartDrawerItems');
        const emptyCartContainer = document.getElementById('emptyCartNotice');
        const cartFooter = document.getElementById('cartDrawerFooter');

        if (!cartItemsContainer) return;

        if (this.cart.length === 0) {
            cartItemsContainer.innerHTML = '';
            emptyCartContainer.classList.remove('hidden');
            cartFooter.classList.add('hidden');
        } else {
            emptyCartContainer.classList.add('hidden');
            cartFooter.classList.remove('hidden');

            cartItemsContainer.innerHTML = this.cart.map((item, idx) => `
                <div class="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-2">
                    <div class="flex items-start justify-between gap-2">
                        <div>
                            <span class="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-orange-100 text-orange-800">
                                30-Day Monthly Pass
                            </span>
                            <h4 class="font-extrabold text-slate-900 text-sm mt-1">${item.name}</h4>
                        </div>
                        <button onclick="app.removeFromCart(${idx})" class="w-7 h-7 text-slate-400 hover:text-rose-500 rounded-lg flex items-center justify-center transition shrink-0">
                            <i class="fa-regular fa-trash-can text-sm"></i>
                        </button>
                    </div>

                    ${item.variant ? `<p class="text-xs text-slate-600 bg-white p-2 rounded-xl border border-slate-200">${item.variant}</p>` : ''}

                    <div class="flex items-center justify-between pt-1">
                        <div class="text-base font-black text-orange-600">₹${item.price * item.qty}</div>
                        <div class="flex items-center bg-white border border-slate-200 rounded-xl shadow-sm">
                            <button onclick="app.updateCartQty(${idx}, -1)" class="w-7 h-7 flex items-center justify-center text-slate-600 hover:text-red-500 font-bold transition">
                                <i class="fa-solid fa-minus text-xs"></i>
                            </button>
                            <span class="w-6 text-center font-bold text-xs text-slate-800">${item.qty}</span>
                            <button onclick="app.updateCartQty(${idx}, 1)" class="w-7 h-7 flex items-center justify-center text-slate-600 hover:text-emerald-500 font-bold transition">
                                <i class="fa-solid fa-plus text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');

            document.getElementById('cartSubtotalValue').textContent = `₹${this.getCartSubtotal()}`;
            document.getElementById('cartDiscountValue').textContent = `-₹${this.getDiscountAmount()}`;
            document.getElementById('cartTotalValue').textContent = `₹${this.getCartTotal()}`;

            const secCheckbox = document.getElementById('firstTimeUserCheckbox');
            if (secCheckbox) {
                secCheckbox.checked = this.isFirstTimeUser;
            }

            const securityRow = document.getElementById('cartSecurityFeeRow');
            const securityVal = document.getElementById('cartSecurityFeeValue');
            if (securityRow && securityVal) {
                securityRow.classList.toggle('hidden', this.getSecurityFee() === 0);
                securityVal.textContent = `+₹${this.getSecurityFee()}`;
            }

            const discountRow = document.getElementById('cartDiscountRow');
            if (discountRow) {
                discountRow.classList.toggle('hidden', this.getDiscountAmount() === 0);
            }
        }
    }

    // ==========================================
    // WEEKLY SCHEDULE EXPLORER
    // ==========================================
    renderWeeklyMenu(dayKey) {
        this.activeScheduleDay = dayKey;
        const data = window.LPU_DATA.weeklySchedule[dayKey];
        const container = document.getElementById('weeklyScheduleContent');
        if (!container || !data) return;

        // Update day pills
        document.querySelectorAll('.day-pill').forEach(btn => {
            const isMatch = btn.getAttribute('data-day') === dayKey;
            btn.classList.toggle('bg-orange-600', isMatch);
            btn.classList.toggle('text-white', isMatch);
            btn.classList.toggle('bg-white', !isMatch);
            btn.classList.toggle('text-slate-700', !isMatch);
        });

        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fadeIn">
                <!-- Lunch Card -->
                <div class="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/60 rounded-3xl p-6 relative overflow-hidden">
                    <div class="flex items-center justify-between mb-4">
                        <span class="px-3 py-1 rounded-full text-xs font-black bg-amber-500 text-white uppercase tracking-wider">
                            <i class="fa-solid fa-sun mr-1"></i> Lunch (12:30 PM - 2:00 PM)
                        </span>
                        <span class="text-xs font-bold text-amber-800 bg-amber-100/80 px-2.5 py-1 rounded-lg">
                            ${data.special}
                        </span>
                    </div>
                    <h4 class="text-xl font-extrabold text-slate-900 mb-2">${data.day} Lunch Menu</h4>
                    <p class="text-slate-700 text-sm leading-relaxed">${data.lunch}</p>

                    <div class="mt-6 pt-4 border-t border-amber-200/60 flex items-center justify-between">
                        <div class="text-xs text-amber-900 font-bold">Included in 1-Time Lunch or Full Board Pass</div>
                        <button onclick="app.selectHeroPlan('veg')" class="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold shrink-0 transition">
                            Choose Plan
                        </button>
                    </div>
                </div>

                <!-- Dinner Card -->
                <div class="bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200/60 rounded-3xl p-6 relative overflow-hidden">
                    <div class="flex items-center justify-between mb-4">
                        <span class="px-3 py-1 rounded-full text-xs font-black bg-indigo-600 text-white uppercase tracking-wider">
                            <i class="fa-solid fa-moon mr-1"></i> Dinner (8:00 PM - 9:00 PM)
                        </span>
                        <span class="text-xs font-bold text-indigo-800 bg-indigo-100/80 px-2.5 py-1 rounded-lg">
                            Serving 8:00 PM - 9:00 PM
                        </span>
                    </div>
                    <h4 class="text-xl font-extrabold text-slate-900 mb-2">${data.day} Dinner Menu</h4>
                    <p class="text-slate-700 text-sm leading-relaxed">${data.dinner}</p>

                    <div class="mt-6 pt-4 border-t border-indigo-200/60 flex items-center justify-between">
                        <div class="text-xs text-indigo-900 font-bold">Sunday bonus: Gulab Jamun / Kheer dessert</div>
                        <button onclick="app.selectHeroPlan('nonveg')" class="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shrink-0 transition">
                            Choose Plan
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // ==========================================
    // SUBSCRIPTIONS (MONTHLY PLANS ONLY)
    // ==========================================
    renderSubscriptions() {
        const container = document.getElementById('subscriptionsGrid');
        if (!container) return;

        container.innerHTML = window.LPU_DATA.subscriptions.map(sub => `
            <div class="bg-white rounded-3xl border ${
                sub.popular 
                    ? 'border-2 border-orange-500 shadow-xl relative scale-[1.01]' 
                    : 'border-slate-200/80 shadow-sm'
            } p-6 sm:p-7 flex flex-col justify-between card-hover">
                
                ${sub.popular ? `
                    <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs font-black px-4 py-1 rounded-full uppercase tracking-wider shadow-md whitespace-nowrap">
                        ${sub.badge}
                    </div>
                ` : ''}

                <div>
                    <div class="flex items-center justify-between gap-2">
                        <span class="text-xs font-bold uppercase tracking-wider text-slate-400">${sub.duration}</span>
                        ${!sub.popular && sub.badge ? `<span class="text-xs font-bold bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-full">${sub.badge}</span>` : ''}
                    </div>
                    <h3 class="font-black text-slate-900 text-xl mt-2 flex items-center gap-2">
                        <span>${sub.name}</span>
                        ${sub.diet === 'veg' ? '<span class="w-3 h-3 rounded-full bg-emerald-500 inline-block shrink-0"></span>' : '<span class="w-3 h-3 rounded-full bg-red-500 inline-block shrink-0"></span>'}
                    </h3>

                    <div class="mt-4 pb-4 border-b border-slate-100">
                        <div class="flex items-baseline gap-2">
                            <span class="text-3xl font-black text-slate-900">₹${sub.price}</span>
                            <span class="text-sm font-semibold text-slate-400 line-through">₹${sub.originalPrice}</span>
                            <span class="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">${sub.savings}</span>
                        </div>
                        <div class="flex items-center gap-2 mt-1">
                            <span class="text-xs font-bold text-slate-500">${sub.perMeal}</span>
                            <span class="text-slate-300">•</span>
                            <span class="text-xs font-bold text-orange-600">Zero PG Delivery Fee</span>
                        </div>
                    </div>

                    <ul class="mt-5 space-y-2.5 text-xs text-slate-600">
                        ${sub.features.map(f => `
                            <li class="flex items-start gap-2.5">
                                <i class="fa-solid fa-circle-check text-emerald-500 text-sm mt-0.5 shrink-0"></i>
                                <span class="font-semibold">${f}</span>
                            </li>
                        `).join('')}
                    </ul>
                </div>

                <div class="mt-7">
                    <button onclick="app.openPlanModal('${sub.id}')" class="w-full py-3.5 ${
                        sub.popular 
                            ? 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 text-white shadow-lg shadow-orange-500/25' 
                            : 'bg-slate-900 hover:bg-slate-800 text-white'
                    } rounded-2xl font-black text-xs transition uppercase tracking-wider flex items-center justify-center gap-2">
                        <span>Select Plan & Meal Timing</span>
                        <i class="fa-solid fa-arrow-right text-xs"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    openPlanModal(subId) {
        const sub = window.LPU_DATA.subscriptions.find(s => s.id === subId);
        if (!sub) return;

        this.selectedSubscription = sub;

        const modal = document.getElementById('planModal');
        const content = document.getElementById('planModalContent');
        if (!modal || !content) return;

        const isOneTime = sub.category === 'onetime-monthly';

        content.innerHTML = `
            <div class="flex items-start gap-3 pb-4 border-b border-slate-100">
                <div class="w-12 h-12 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-xl shrink-0">
                    <i class="fa-solid fa-calendar-check"></i>
                </div>
                <div>
                    <div class="text-[10px] font-black uppercase text-orange-600">${sub.duration}</div>
                    <h3 class="font-black text-slate-900 text-lg">${sub.name}</h3>
                    <div class="text-base font-black text-slate-900 mt-0.5">₹${sub.price} <span class="text-xs font-normal text-slate-500">(${sub.perMeal})</span></div>
                </div>
            </div>

            <div class="py-4 space-y-4">
                ${isOneTime ? `
                    <div>
                        <label class="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2">
                            Choose Your Daily 1-Time Meal Window *
                        </label>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                            <label class="flex flex-col p-3 rounded-2xl border-2 border-slate-200 cursor-pointer hover:border-orange-400 has-[:checked]:border-orange-500 has-[:checked]:bg-orange-50/50">
                                <div class="flex items-center justify-between">
                                    <span class="font-black text-slate-900">Lunch Only</span>
                                    <input type="radio" name="planMealSlot" value="Lunch (12:30 PM - 2:00 PM)" checked class="text-orange-500">
                                </div>
                                <span class="text-[11px] text-slate-500 mt-1">12:30 PM - 2:00 PM</span>
                            </label>

                            <label class="flex flex-col p-3 rounded-2xl border-2 border-slate-200 cursor-pointer hover:border-orange-400 has-[:checked]:border-orange-500 has-[:checked]:bg-orange-50/50">
                                <div class="flex items-center justify-between">
                                    <span class="font-black text-slate-900">Dinner Only</span>
                                    <input type="radio" name="planMealSlot" value="Dinner (8:00 PM - 9:00 PM)" class="text-orange-500">
                                </div>
                                <span class="text-[11px] text-slate-500 mt-1">8:00 PM - 9:00 PM</span>
                            </label>

                            <label class="flex flex-col p-3 rounded-2xl border-2 border-slate-200 cursor-pointer hover:border-orange-400 has-[:checked]:border-orange-500 has-[:checked]:bg-orange-50/50">
                                <div class="flex items-center justify-between">
                                    <span class="font-black text-slate-900">Flexible Daily</span>
                                    <input type="radio" name="planMealSlot" value="Flexible (WhatsApp Switch Daily)" class="text-orange-500">
                                </div>
                                <span class="text-[11px] text-slate-500 mt-1">Switch anytime via WhatsApp</span>
                            </label>
                        </div>
                    </div>
                ` : `
                    <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900">
                        <i class="fa-solid fa-circle-check text-emerald-600 mr-1"></i>
                        <strong>Full Board Included:</strong> You will receive both hot Lunch (12:30-2:00 PM) and Dinner (8:00-9:00 PM) daily!
                    </div>
                `}

                <div>
                    <label class="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1">Dietary / Taste Note (Optional)</label>
                    <input type="text" id="planTasteNote" placeholder="e.g. Less spicy / Extra lemon / No garlic / Jain preference" class="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-orange-500 focus:outline-none">
                </div>

                ${sub.razorpayUrl ? `
                    <div class="p-3.5 ${sub.diet === 'veg' ? 'bg-emerald-50/80 border-emerald-200' : 'bg-blue-50/80 border-blue-200'} border rounded-2xl flex items-center justify-between gap-3">
                        <div class="flex items-center gap-2.5">
                            <div class="w-8 h-8 rounded-xl ${sub.diet === 'veg' ? 'bg-emerald-600' : 'bg-blue-600'} text-white flex items-center justify-center text-xs font-bold shrink-0">
                                <i class="fa-solid fa-credit-card"></i>
                            </div>
                            <div>
                                <div class="font-extrabold ${sub.diet === 'veg' ? 'text-emerald-900' : 'text-blue-900'} text-xs">
                                    Official Razorpay Gateway
                                </div>
                                <div class="text-[10px] ${sub.diet === 'veg' ? 'text-emerald-700' : 'text-blue-700'}">Instant online payment for ${sub.name}</div>
                            </div>
                        </div>
                        <a href="${sub.razorpayUrl}" target="_blank" class="px-3.5 py-2 ${sub.diet === 'veg' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-600/20'} text-white rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 shadow-md transition">
                            <span>Pay ₹${sub.price}</span>
                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                        </a>
                    </div>
                ` : ''}

                <div class="bg-slate-50 rounded-2xl p-3 border border-slate-100 text-[11px] text-slate-600 space-y-1">
                    <div><i class="fa-solid fa-shield-check text-emerald-600 mr-1"></i> <strong>Vacation Pause Guarantee:</strong> Up to 4 pauses included per month.</div>
                    <div><i class="fa-solid fa-truck-fast text-orange-600 mr-1"></i> <strong>Off-Campus Doorstep Drop:</strong> Free delivery in Law Gate, Green Valley & Hardaspur PGs.</div>
                    <div><i class="fa-solid fa-phone text-emerald-600 mr-1"></i> <strong>WhatsApp Support:</strong> +91 97078 89516</div>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                    <div class="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Total Subscription</div>
                    <div class="text-2xl font-black text-slate-900">₹${sub.price}</div>
                </div>
                <div class="flex items-center gap-2">
                    ${sub.razorpayUrl ? `
                        <a href="${sub.razorpayUrl}" target="_blank" class="px-4 py-3 ${sub.diet === 'veg' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20' : 'bg-red-600 hover:bg-red-700 shadow-red-600/20'} text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md transition flex items-center gap-1.5">
                            <span>Pay ₹${sub.price}</span>
                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                        </a>
                    ` : ''}
                    <button onclick="app.confirmPlanToCart()" class="px-5 py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md transition">
                        Add to Bag
                    </button>
                </div>
            </div>
        `;

        modal.classList.remove('hidden');
    }

    confirmPlanToCart() {
        if (!this.selectedSubscription) return;

        const sub = this.selectedSubscription;
        const slotEl = document.querySelector('input[name="planMealSlot"]:checked');
        const mealSlot = slotEl ? slotEl.value : 'Both Lunch & Dinner';
        const note = document.getElementById('planTasteNote')?.value.trim();

        const variant = note ? `${mealSlot} • Note: ${note}` : mealSlot;

        this.addToCart({
            id: `${sub.id}-${Date.now()}`,
            name: sub.name,
            price: sub.price,
            type: 'subscription',
            variant: variant,
            image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=400&q=80',
            qty: 1
        });

        this.closeModal('planModal');
        this.openModal('cartDrawer');
    }

    selectHeroPlan(planType) {
        if (planType === 'veg') {
            this.openPlanModal('sub-1time-veg');
        } else {
            this.openPlanModal('sub-1time-nonveg');
        }
    }

    // ==========================================
    // REVIEWS & FAQS
    // ==========================================
    renderReviews() {
        const container = document.getElementById('reviewsGrid');
        if (!container) return;

        container.innerHTML = window.LPU_DATA.reviews.map(rev => `
            <div class="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between card-hover">
                <div>
                    <div class="flex items-center gap-1 text-amber-400 text-xs mb-3">
                        ${Array(rev.rating).fill('<i class="fa-solid fa-star"></i>').join('')}
                    </div>
                    <p class="text-slate-600 text-xs leading-relaxed italic">"${rev.comment}"</p>
                </div>

                <div class="mt-6 pt-4 border-t border-slate-100 flex items-center gap-3">
                    <img src="${rev.avatar}" alt="${rev.name}" class="w-10 h-10 rounded-full object-cover">
                    <div>
                        <h5 class="font-extrabold text-slate-900 text-sm">${rev.name}</h5>
                        <p class="text-[11px] text-slate-500">${rev.role} • <span class="font-bold text-orange-600">${rev.hostel}</span></p>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderFaqs() {
        const container = document.getElementById('faqsAccordion');
        if (!container) return;

        container.innerHTML = window.LPU_DATA.faqs.map((faq, idx) => `
            <div class="border border-slate-200/80 rounded-2xl overflow-hidden bg-white">
                <button onclick="app.toggleFaq(${idx})" class="w-full p-4 sm:p-5 text-left font-bold text-slate-800 text-sm flex items-center justify-between gap-4 hover:bg-slate-50 transition">
                    <span>${faq.q}</span>
                    <i id="faq-icon-${idx}" class="fa-solid fa-chevron-down text-xs text-slate-400 transition-transform duration-200"></i>
                </button>
                <div id="faq-ans-${idx}" class="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed hidden border-t border-slate-100 bg-slate-50/50">
                    ${faq.a}
                </div>
            </div>
        `).join('');
    }

    toggleFaq(index) {
        const ans = document.getElementById(`faq-ans-${index}`);
        const icon = document.getElementById(`faq-icon-${index}`);
        if (ans && icon) {
            const isHidden = ans.classList.contains('hidden');
            ans.classList.toggle('hidden', !isHidden);
            icon.classList.toggle('rotate-180', isHidden);
        }
    }

    // ==========================================
    // POPULATE HOSTEL DROPDOWNS
    // ==========================================
    populateHostelDropdowns() {
        const sel = document.getElementById('checkoutHostelSelect');
        if (!sel) return;

        sel.innerHTML = '<option value="">Select your PG / Flat location...</option>' + 
            window.LPU_DATA.hostelLocations.map(group => `
                <optgroup label="${group.group}">
                    ${group.items.map(item => `<option value="${item}">${item}</option>`).join('')}
                </optgroup>
            `).join('');

        const slotSelect = document.getElementById('checkoutTimeSlot');
        if (slotSelect) {
            slotSelect.innerHTML = `
                <option value="">Select preferred delivery slot...</option>
                <optgroup label="Tiffin Lunch Hours">
                    ${window.LPU_DATA.deliverySlots.tiffinLunch.map(s => `<option value="Lunch: ${s}">Lunch: ${s}</option>`).join('')}
                </optgroup>
                <optgroup label="Tiffin Dinner Hours">
                    ${window.LPU_DATA.deliverySlots.tiffinDinner.map(s => `<option value="Dinner: ${s}">Dinner: ${s}</option>`).join('')}
                </optgroup>
            `;
        }
    }

    // ==========================================
    // COUPONS
    // ==========================================
    applyCoupon(code) {
        const clean = (code || '').trim().toUpperCase();
        const coupon = window.LPU_DATA.coupons[clean];
        const subtotal = this.getCartSubtotal();

        if (!coupon) {
            this.showToast("Invalid coupon! Try 'RASOOI100' or 'TIFFIN150' 🏷️", true);
            return;
        }

        if (subtotal < coupon.minAmount) {
            this.showToast(`Minimum plan value of ₹${coupon.minAmount} required for this coupon`, true);
            return;
        }

        this.appliedCoupon = coupon;
        this.updateCartUI();
        this.showToast(`Coupon "${clean}" applied! (${coupon.desc}) 🎉`);
    }

    // ==========================================
    // CHECKOUT & WHATSAPP GENERATION
    // ==========================================
    openCheckout() {
        if (this.cart.length === 0) {
            this.showToast("Please choose a monthly subscription plan first!", true);
            return;
        }
        this.closeModal('cartDrawer');
        const modal = document.getElementById('checkoutModal');
        if (modal) {
            document.getElementById('checkoutFinalTotal').textContent = `₹${this.getCartTotal()}`;
            const depositNotice = document.getElementById('checkoutDepositNotice');
            if (depositNotice) {
                if (this.getSecurityFee() > 0) {
                    depositNotice.classList.remove('hidden');
                } else {
                    depositNotice.classList.add('hidden');
                }
            }
            modal.classList.remove('hidden');
        }
    }

    processOrder(e) {
        if (e) e.preventDefault();

        const name = document.getElementById('checkoutName')?.value.trim();
        const phone = document.getElementById('checkoutPhone')?.value.trim();
        const hostel = document.getElementById('checkoutHostelSelect')?.value;
        const room = document.getElementById('checkoutRoom')?.value.trim();
        const slot = document.getElementById('checkoutTimeSlot')?.value;
        const payment = document.querySelector('input[name="checkoutPayment"]:checked')?.value || 'UPI / Online QR';
        const notes = document.getElementById('checkoutNotes')?.value.trim();

        if (!name || !phone || !hostel || !room || !slot) {
            this.showToast("Please fill in your Name, Phone, Delivery Area, PG/Room, and Meal Window", true);
            return;
        }

        const orderId = 'RASOOI-' + Math.floor(1000 + Math.random() * 9000);
        const total = this.getCartTotal();
        const depositFee = this.getSecurityFee();

        const itemsSummary = this.cart.map(i => `${i.qty}x ${i.name} (${i.variant || 'Monthly Pass'})`).join(', ');

        const orderObj = {
            id: orderId,
            createdAt: new Date().toISOString(),
            type: "subscription",
            itemsSummary: itemsSummary,
            location: hostel,
            room: `PG/Flat: ${room}`,
            customerName: name,
            phone: phone,
            total: total,
            isFirstTimeUser: this.isFirstTimeUser,
            securityDeposit: depositFee,
            paymentMethod: payment,
            slot: slot,
            notes: notes,
            statusStage: 0,
            statusText: "Subscription Enrolled & Acknowledged",
            rider: {
                name: "Maninder Singh (Rasooi Dedicated Partner)",
                phone: "+91 97078 89516",
                eta: "Slot Scheduled: " + slot,
                bike: "Rasooi Delivery Fleet"
            }
        };

        window.orderTracker.saveOrder(orderObj);

        const isNonVeg = itemsSummary.includes('Non-Veg');
        const isVeg = itemsSummary.includes('Pure Veg') || itemsSummary.includes('Veg');
        const rzpUrl = isNonVeg ? window.LPU_DATA.razorpayNonVegUrl : (isVeg ? window.LPU_DATA.razorpayVegUrl : '');

        // Build WhatsApp text
        const waText = `🍲 *NEW MONTHLY TIFFIN SUBSCRIPTION - RASOOI!* 🍲
_Fooding Made Easy (Law Gate • Green Valley • Hardaspur)_
----------------------------------
🆔 *Subscription ID:* ${orderId}
👤 *Student Name:* ${name}
📞 *WhatsApp:* ${phone}
📍 *Area:* ${hostel}
🚪 *PG / Flat Details:* ${room}
⏰ *Preferred Meal Window:* ${slot}
💳 *Payment Mode:* ${payment}
${depositFee > 0 ? `📦 *Tiffin Security Fee (1st Time User):* ₹${depositFee} (100% Refundable Deposit)\n` : ''}${rzpUrl ? `🔗 *Razorpay Payment Link:* ${rzpUrl}\n` : ''}----------------------------------
🍛 *MONTHLY SUBSCRIPTION PLAN:*
${this.cart.map((item, idx) => `${idx + 1}. *${item.name}* [₹${item.price * item.qty}] ${item.variant ? `\n   - Timing/Spec: ${item.variant}` : ''}`).join('\n')}
----------------------------------
💰 *Total Payable:* ₹${total}${depositFee > 0 ? ` (Plan + ₹${depositFee} Refundable Tiffin Deposit)` : ''}
${notes ? `📝 *Dietary / Landmark Note:* ${notes}` : ''}
----------------------------------
_Please confirm my Rasooi monthly subscription and activate daily delivery._`;

        this.clearCart();
        this.closeModal('checkoutModal');
        this.showSuccessModal(orderObj, waText);
    }

    showSuccessModal(order, waText) {
        const modal = document.getElementById('orderSuccessModal');
        const container = document.getElementById('orderSuccessContent');
        if (!modal || !container) return;

        const waUrl = `https://wa.me/${window.LPU_DATA.whatsappNumber}?text=${encodeURIComponent(waText)}`;
        const isNonVeg = Boolean(order.itemsSummary && order.itemsSummary.includes('Non-Veg'));
        const isVeg = Boolean(order.itemsSummary && (order.itemsSummary.includes('Pure Veg') || order.itemsSummary.includes('Veg')));
        const rzpUrl = isNonVeg ? window.LPU_DATA.razorpayNonVegUrl : (isVeg ? window.LPU_DATA.razorpayVegUrl : '');
        const showRzpButton = (order.paymentMethod && order.paymentMethod.includes('Razorpay')) || Boolean(rzpUrl);

        container.innerHTML = `
            <div class="text-center py-4">
                <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-3xl mx-auto mb-4 animate-bounce">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
                <h3 class="text-2xl font-black text-slate-900">Subscription Confirmed!</h3>
                <p class="text-xs text-slate-500 mt-1">Rasooi: Fooding Made Easy (Law Gate • Green Valley • Hardaspur)</p>

                <div class="bg-slate-50 border border-slate-200 rounded-2xl p-4 my-5 text-left">
                    <div class="flex items-center justify-between text-xs text-slate-500 mb-1">
                        <span>Subscription Reference</span>
                        <span class="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">Active Pass</span>
                    </div>
                    <div class="font-mono font-black text-2xl text-slate-900 tracking-wider">${order.id}</div>
                    
                    <div class="mt-3 pt-3 border-t border-slate-200/80 text-xs text-slate-600 space-y-1">
                        <div><strong>PG / Flat Destination:</strong> ${order.location} (${order.room})</div>
                        <div><strong>Delivery Window:</strong> ${order.slot}</div>
                        ${order.securityDeposit ? `<div class="text-amber-800"><strong>Tiffin Deposit (1st-Time User):</strong> +₹${order.securityDeposit} <span class="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">100% Refundable</span></div>` : ''}
                        <div><strong>Total Amount:</strong> <span class="font-black text-slate-900">₹${order.total}</span> (${order.paymentMethod})</div>
                    </div>
                </div>

                <div class="space-y-3">
                    ${showRzpButton && rzpUrl ? `
                        <a href="${rzpUrl}" target="_blank" class="w-full py-3.5 bg-gradient-to-r ${isVeg ? 'from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-600/25' : 'from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-blue-600/25'} text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition">
                            <i class="fa-solid fa-credit-card"></i> Pay ₹${order.total} on Razorpay Now <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                        </a>
                    ` : ''}

                    <a href="${waUrl}" target="_blank" class="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition">
                        <i class="fa-brands fa-whatsapp text-lg"></i> Send Order Details to WhatsApp (+91 97078 89516)
                    </a>

                    <button onclick="app.closeModal('orderSuccessModal'); app.viewTracker('${order.id}')" class="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition">
                        <i class="fa-solid fa-location-crosshairs"></i> Track Live Subscription Status
                    </button>
                </div>
            </div>
        `;

        modal.classList.remove('hidden');
    }

    viewTracker(orderId) {
        const trackSection = document.getElementById('trackingSection');
        if (trackSection) {
            trackSection.scrollIntoView({ behavior: 'smooth' });
            const input = document.getElementById('trackOrderInput');
            if (input) input.value = orderId;
            window.trackOrderManual();
        }
    }

    openModal(modalId) {
        const el = document.getElementById(modalId);
        if (el) el.classList.remove('hidden');
    }

    closeModal(modalId) {
        const el = document.getElementById(modalId);
        if (el) el.classList.add('hidden');
    }

    showToast(message, isError = false) {
        const toast = document.getElementById('appToast');
        const text = document.getElementById('appToastText');
        if (!toast || !text) return;

        text.textContent = message;
        toast.className = `fixed top-5 right-5 z-50 px-5 py-3 rounded-2xl shadow-2xl font-bold text-xs flex items-center gap-2 text-white transition-all transform duration-300 ${
            isError ? 'bg-rose-600' : 'bg-slate-900'
        }`;

        toast.classList.remove('hidden', 'translate-y-[-20px]', 'opacity-0');

        setTimeout(() => {
            toast.classList.add('translate-y-[-20px]', 'opacity-0');
            setTimeout(() => toast.classList.add('hidden'), 300);
        }, 3200);
    }

    setupEventListeners() {
        // Event listeners for UI tabs
    }
}

window.app = new AppController();

window.trackOrderManual = function() {
    const input = document.getElementById('trackOrderInput');
    const container = document.getElementById('trackingResultsContainer');
    if (!input || !container) return;
    const orderId = input.value.trim();
    if (!orderId) {
        window.app.showToast("Please enter an Order / Subscription ID to track", true);
        return;
    }
    window.orderTracker.renderTracker(orderId, container);
};

document.addEventListener('DOMContentLoaded', () => {
    window.app.init();
    
    const defaultTrackerContainer = document.getElementById('trackingResultsContainer');
    if (defaultTrackerContainer) {
        window.orderTracker.renderTracker("RASOOI-7821", defaultTrackerContainer);
    }
});
