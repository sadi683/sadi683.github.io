/**
 * Rasooi - Fooding Made Easy
 * Off-Campus Tiffin Order & Subscription Tracker Engine
 * Serving Law Gate, Green Valley, Hardaspur & Nearby PGs
 */

class OrderTracker {
    constructor() {
        this.storageKey = 'rasooi_tiffin_orders';
        this.activeOrderId = null;
    }

    getOrders() {
        try {
            const data = localStorage.getItem(this.storageKey);
            return data ? JSON.parse(data) : this.getDemoOrders();
        } catch (e) {
            return this.getDemoOrders();
        }
    }

    saveOrder(order) {
        const orders = this.getOrders();
        orders.unshift(order);
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(orders.slice(0, 20)));
        } catch (e) {
            console.error("Storage error:", e);
        }

        if (window.location.protocol.startsWith('http')) {
            try {
                fetch('/api/orders', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(order)
                }).catch(() => {});
            } catch (err) {}
        }

        return order;
    }

    getDemoOrders() {
        return [
            {
                id: "RASOOI-7821",
                createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
                type: "tiffin",
                itemsSummary: "1-Time Daily Pure Veg Monthly Plan (₹2,599) - Dinner Slot",
                location: "Law Gate - Khalsa Street PG",
                room: "Room 204, Floor 2",
                customerName: "Harshit Verma",
                phone: "9876543210",
                total: 2599,
                paymentMethod: "UPI Online",
                statusStage: 3,
                statusText: "Out for Delivery to Law Gate PG",
                rider: {
                    name: "Sukhwinder (Rasooi Delivery Rider)",
                    phone: "+91 97078 89516",
                    eta: "8 Mins",
                    bike: "Hero Splendor PB-08-AB"
                }
            },
            {
                id: "RASOOI-6349",
                createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
                type: "tiffin",
                itemsSummary: "1-Time Daily Non-Veg Delight Monthly Plan (₹2,999) - Dinner Slot",
                location: "Green Valley - Block B Flats",
                room: "Flat 302",
                customerName: "Rohit Deshmukh",
                phone: "9812345678",
                total: 2999,
                paymentMethod: "UPI Online",
                statusStage: 2,
                statusText: "Packed in Insulated Thermal Box",
                rider: {
                    name: "Aman (Rasooi Delivery Team)",
                    phone: "+91 97078 89516",
                    eta: "Scheduled: 8:15 PM Doorstep Drop",
                    bike: "Electric Delivery Van"
                }
            }
        ];
    }

    findOrder(orderId) {
        const idClean = (orderId || '').trim().toUpperCase();
        const orders = this.getOrders();
        return orders.find(o => 
            o.id.toUpperCase() === idClean || 
            o.id.toUpperCase() === `RASOOI-${idClean}` ||
            o.id.toUpperCase() === `LPU-${idClean}`
        );
    }

    renderTracker(orderId, containerEl) {
        if (!containerEl) return;
        const order = this.findOrder(orderId);

        if (!order) {
            containerEl.innerHTML = `
                <div class="bg-rose-50 border border-rose-200 text-rose-800 p-6 rounded-2xl text-center">
                    <i class="fa-solid fa-triangle-exclamation text-3xl text-rose-500 mb-3 block"></i>
                    <h4 class="font-bold text-lg">Rasooi Order Not Found</h4>
                    <p class="text-sm text-rose-600 mt-1">We couldn't find order <strong>"${orderId}"</strong>. Please check your Order ID or try sample ID: <strong>RASOOI-7821</strong>.</p>
                    <button onclick="document.getElementById('trackOrderInput').value='RASOOI-7821'; window.trackOrderManual();" class="mt-4 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-sm font-semibold transition shadow-sm">
                        Try Sample Order RASOOI-7821
                    </button>
                </div>
            `;
            return;
        }

        const stages = [
            { title: "Order Confirmed", desc: "Received at Rasooi Law Gate Kitchen Hub", icon: "fa-receipt" },
            { 
                title: "Chef Cooking Fresh", 
                desc: "100% whole wheat phulkas & hot dal with pure desi ghee tadka", 
                icon: "fa-fire-burner" 
            },
            { 
                title: "Packed in Insulated Thermal Box", 
                desc: "Hygienic sealed packaging with room tag (keeps hot for 2+ hrs)", 
                icon: "fa-box-open" 
            },
            { 
                title: "Out for Doorstep Delivery", 
                desc: `Rider enroute to ${order.location}`, 
                icon: "fa-motorcycle" 
            },
            { 
                title: "Delivered to PG / Flat", 
                desc: `Handed over directly to student at room/flat door`, 
                icon: "fa-circle-check" 
            }
        ];

        const currentStage = Math.min(order.statusStage || 2, 4);

        let stagesHtml = stages.map((st, idx) => {
            const isCompleted = idx < currentStage;
            const isCurrent = idx === currentStage;

            let badgeClass = isCompleted 
                ? "bg-emerald-500 text-white shadow-emerald-200" 
                : isCurrent 
                    ? "bg-amber-500 text-white animate-pulse ring-4 ring-amber-100 shadow-amber-200" 
                    : "bg-slate-200 text-slate-400";
            
            let textClass = isCompleted 
                ? "text-emerald-950 font-bold" 
                : isCurrent 
                    ? "text-amber-900 font-bold" 
                    : "text-slate-400";

            return `
                <div class="flex items-start gap-4 relative">
                    ${idx < stages.length - 1 ? `
                        <div class="absolute left-5 top-10 bottom-0 w-0.5 ${idx < currentStage ? 'bg-emerald-500' : 'bg-slate-200'}"></div>
                    ` : ''}
                    <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${badgeClass} shadow-md z-10">
                        <i class="fa-solid ${isCompleted ? 'fa-check' : st.icon}"></i>
                    </div>
                    <div class="pb-6">
                        <div class="flex items-center gap-2">
                            <h4 class="text-base ${textClass}">${st.title}</h4>
                            ${isCurrent ? `<span class="bg-amber-100 text-amber-800 text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">In Progress</span>` : ''}
                            ${isCompleted ? `<span class="bg-emerald-100 text-emerald-800 text-xs px-2 py-0.5 rounded-full font-semibold">Done</span>` : ''}
                        </div>
                        <p class="text-xs text-slate-500 mt-0.5">${st.desc}</p>
                    </div>
                </div>
            `;
        }).join('');

        const riderHtml = order.rider ? `
            <div class="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/80 rounded-2xl p-4 flex items-center justify-between gap-4 mt-6">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-amber-600 text-white flex items-center justify-center text-lg font-black shadow-md">
                        <i class="fa-solid fa-person-biking"></i>
                    </div>
                    <div>
                        <div class="text-xs uppercase tracking-wider text-amber-700 font-bold">Assigned Rasooi Delivery Rider</div>
                        <div class="font-bold text-slate-800 text-base">${order.rider.name}</div>
                        <div class="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                            <span><i class="fa-solid fa-motorcycle text-amber-600"></i> ${order.rider.bike}</span>
                            <span>•</span>
                            <span class="text-emerald-600 font-bold"><i class="fa-solid fa-clock"></i> ETA: ${order.rider.eta}</span>
                        </div>
                    </div>
                </div>
                <a href="tel:${order.rider.phone}" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-md flex items-center gap-2 transition shrink-0">
                    <i class="fa-solid fa-phone"></i> Call Rider (${order.rider.phone})
                </a>
            </div>
        ` : '';

        containerEl.innerHTML = `
            <div class="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-6 sm:p-8 animate-fadeIn">
                <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-5">
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="bg-orange-100 text-orange-700 font-black text-xs px-3 py-1 rounded-full uppercase tracking-wide">
                                RASOOI TIFFIN
                            </span>
                            <span class="text-xs font-semibold text-slate-400">Order ID</span>
                            <span class="font-mono font-bold text-slate-900 text-lg">${order.id}</span>
                        </div>
                        <div class="text-xs text-slate-500 mt-1">
                            Placed on ${new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-xs text-slate-400 font-medium">Total Amount</div>
                        <div class="text-2xl font-black text-slate-900">₹${order.total}</div>
                        <span class="inline-block text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md mt-0.5">
                            <i class="fa-solid fa-shield-check"></i> ${order.paymentMethod}
                        </span>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 rounded-2xl p-4 my-6 border border-slate-100">
                    <div class="flex items-start gap-3">
                        <div class="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-600 flex items-center justify-center shrink-0 mt-0.5">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                        <div>
                            <div class="text-xs text-slate-400 font-bold uppercase tracking-wider">PG / Flat Destination</div>
                            <div class="text-sm font-bold text-slate-800">${order.location}</div>
                            <div class="text-xs text-slate-600 font-semibold">${order.room} • ${order.customerName} (${order.phone})</div>
                        </div>
                    </div>
                    <div class="flex items-start gap-3">
                        <div class="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0 mt-0.5">
                            <i class="fa-solid fa-utensils"></i>
                        </div>
                        <div>
                            <div class="text-xs text-slate-400 font-bold uppercase tracking-wider">Tiffin Plan / Items</div>
                            <div class="text-sm font-semibold text-slate-800 line-clamp-2">${order.itemsSummary}</div>
                        </div>
                    </div>
                </div>

                <div class="mt-8 ml-2">
                    <h5 class="text-xs font-black uppercase tracking-wider text-slate-400 mb-6">Live Doorstep Delivery Timeline</h5>
                    ${stagesHtml}
                </div>

                ${riderHtml}

                <div class="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
                    <div class="flex items-center gap-2">
                        <i class="fa-solid fa-shield-heart text-amber-500"></i>
                        <span>Need to pause meals or change timing? WhatsApp us at 9707889516</span>
                    </div>
                    <a href="https://wa.me/919707889516?text=Hi%20Rasooi,%20query%20regarding%20Tiffin%20Order%20${encodeURIComponent(order.id)}" target="_blank" class="text-emerald-700 font-bold hover:underline flex items-center gap-1.5">
                        <i class="fa-brands fa-whatsapp text-sm"></i> WhatsApp Support (+91 97078 89516)
                    </a>
                </div>
            </div>
        `;
    }
}

window.orderTracker = new OrderTracker();
