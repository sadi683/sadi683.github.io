/**
 * Rasooi - Fooding Made Easy
 * Monthly Tiffin Subscriptions Only (Law Gate, Green Valley, Hardaspur & Nearby PGs)
 * WhatsApp: +91 97078 89516
 */

const LPU_DATA = {
    appName: "Rasooi",
    tagline: "Fooding Made Easy",
    whatsappNumber: "919707889516",
    vendorHelpline: "+91 97078 89516",
    razorpayVegUrl: "https://rzp.io/rzp/ALIkEfoh",
    razorpayNonVegUrl: "https://rzp.io/rzp/5T62orL",
    refundableTiffinSecurityDeposit: 1000,
    hubAddress: "Shop 14, Main Market, Law Gate, Phagwara, Punjab",

    hostelLocations: [
        { 
            group: "Law Gate PGs & Flats", 
            items: [
                "Law Gate - Main Market", 
                "Law Gate - Khalsa Street", 
                "Law Gate - Near Gate 1 / GT Road", 
                "Law Gate - Street 1 & 2 PGs",
                "Law Gate - Street 3 & 4 PGs",
                "Law Gate - Royal Enclave / Sunshine PGs"
            ] 
        },
        { 
            group: "Green Valley PGs & Flats", 
            items: [
                "Green Valley - PG Colony Block A", 
                "Green Valley - PG Colony Block B", 
                "Green Valley - Main Road Flats",
                "Green Valley - Near Park PGs"
            ] 
        },
        { 
            group: "Hardaspur Area", 
            items: [
                "Hardaspur - Main Village PGs", 
                "Hardaspur - Student PG Enclave", 
                "Hardaspur - GT Road Crossing Flats",
                "Hardaspur - Near Gurdwara Sahib PGs"
            ] 
        },
        { 
            group: "Nearby Off-Campus PG Hubs", 
            items: [
                "Maheru Village PGs", 
                "Deep Nagar Area", 
                "Chaheru Road Flats",
                "Phagwara Highway PG Hub"
            ] 
        }
    ],

    deliverySlots: {
        tiffinLunch: ["12:30 PM - 1:30 PM", "1:30 PM - 2:30 PM"],
        tiffinDinner: ["8:00 PM - 9:00 PM"]
    },

    // MONTHLY SUBSCRIPTION PLANS ONLY
    subscriptions: [
        {
            id: "sub-1time-veg",
            name: "1-Time Daily Pure Veg Monthly Plan",
            category: "onetime-monthly",
            diet: "veg",
            price: 2599,
            originalPrice: 3300,
            razorpayUrl: "https://rzp.io/rzp/ALIkEfoh",
            duration: "30 Days (Lunch OR Dinner - 1 Meal/Day)",
            perMeal: "Only ₹86 / meal",
            savings: "Save ₹701 / month",
            popular: true,
            badge: "2 Din Paneer + Market Sabzis 🧀🥦",
            features: [
                "2 Din Paneer: Kadhai Paneer (Wed) & Paneer Butter Masala Feast (Sun)",
                "5 Din Daily Market Sabzis: Aloo Gobi, Bhindi Masala, Mix Veg, Dum Aloo, Baingan Bharta",
                "Complete Thali: 4 Desi Ghee Phulkas, Dal (Tadka/Makhani/Rajma/Kadhi), Basmati Rice & Salad",
                "Daily Choice: Choose Lunch (12:30-2:00 PM) OR Dinner (8:00-9:00 PM)",
                "Free Special Sunday Feast & Sweet dish (Gulab Jamun / Kheer)",
                "Doorstep delivery to your PG / Flat in Law Gate, Green Valley & Hardaspur",
                "Up to 4 Meal Pauses with automatic validity extension (WhatsApp 9707889516)",
                "100% Whole wheat, pure desi ghee, zero soda, home kitchen hygiene"
            ]
        },
        {
            id: "sub-1time-nonveg",
            name: "1-Time Daily Non-Veg Delight Monthly Plan",
            category: "onetime-monthly",
            diet: "non-veg",
            price: 2999,
            originalPrice: 3900,
            razorpayUrl: "https://rzp.io/rzp/5T62orL",
            duration: "30 Days (Lunch OR Dinner - 1 Meal/Day)",
            perMeal: "Only ₹99 / meal",
            savings: "Save ₹901 / month",
            popular: true,
            badge: "3 Chicken • 1 Egg • 1 Fish/Paneer 🍗",
            features: [
                "3 Din Chicken: Wed (Dhaba Chicken), Fri (Tariwala Chicken), Sun (Butter Chicken)",
                "1 Din Anda: Mon (Homestyle Punjabi Egg Curry Thali - 2 Eggs)",
                "1 Din Fish ya Paneer: Sat (Amritsari Fish Curry OR Kadhai Paneer)",
                "Pure Veg Days: Tue (Rajma Chawal) & Thu (Matar Paneer & Pindi Chole)",
                "Daily Choice: Choose Lunch (12:30-2:00 PM) OR Dinner (8:00-9:00 PM)",
                "Doorstep delivery to Law Gate, Green Valley & Hardaspur PGs",
                "Up to 4 Meal Pauses with validity extension (via WhatsApp 9707889516)",
                "100% Halal fresh cuts, desi ghee phulkas, zero synthetic colors"
            ]
        },
        {
            id: "sub-both-meals-veg",
            name: "30-Day Full Board Veg Pass (Lunch + Dinner)",
            category: "fullboard",
            diet: "veg",
            price: 4899,
            originalPrice: 6200,
            duration: "30 Days (Both Lunch AND Dinner - 60 Meals)",
            perMeal: "₹81 / meal",
            savings: "Save ₹1,301 / month",
            badge: "Pure Veg 60 Meals Pass",
            features: [
                "2 Din Paneer + 5 Din Market-Fresh Sabzis rotated weekly",
                "Complete freedom: Fresh Lunch (12:30-2:00 PM) + Fresh Hot Dinner (8:00-9:00 PM) daily",
                "4 Desi Ghee Phulkas per meal, Dal, Sabzi/Paneer, Basmati Rice & Salad",
                "Delivered right to your PG room / flat door in Law Gate, Green Valley & Hardaspur",
                "Up to 6 Meal Pauses with automatic rollover validity",
                "Free dessert on Wednesdays and Sundays"
            ]
        },
        {
            id: "sub-both-meals-nonveg",
            name: "30-Day Full Board Non-Veg Pass (Lunch + Dinner)",
            category: "fullboard",
            diet: "non-veg",
            price: 5699,
            originalPrice: 7200,
            duration: "30 Days (Both Lunch AND Dinner - 60 Meals)",
            perMeal: "₹94 / meal",
            savings: "Save ₹1,501 / month",
            badge: "Ultimate Non-Veg Feast",
            features: [
                "Weekly Rotation: 3 Din Chicken 🍗 + 1 Din Anda 🥚 + 1 Din Fish ya Paneer 🐟🧀",
                "Both Meals Daily: Hot Lunch (12:30-2:00 PM) + Dinner (8:00-9:00 PM)",
                "High protein nutrition with fresh halal chicken, eggs, fish & rich paneer",
                "Doorstep delivery to your room in Law Gate, Green Valley & Hardaspur",
                "Up to 6 Meal Pauses with automatic rollover validity",
                "Dedicated WhatsApp hotline coordinator at 9707889516"
            ]
        }
    ],

    // 7-DAY ROTATING SUBSCRIPTION MENU SCHEDULE
    weeklySchedule: {
        monday: {
            day: "Monday",
            special: "🥚 1 Din Anda (Non-Veg) • 🥦 Market Mix Veg (Pure Veg)",
            lunch: "Dal Tadka, Seasonal Mix Veg (Gobi/Matar/Beans), Steamed Basmati Rice, 4 Butter Phulkas, Mint Chutney & Salad",
            dinner: "Non-Veg: Punjabi Egg Curry (2 Boiled Eggs) | Pure Veg: Homestyle Aloo Matar / Seasonal Sabzi, Yellow Dal Fry, Jeera Rice, 4 Desi Ghee Phulkas, Boondi Raita, Gulab Jamun",
            snack: "Bread Pakora / Tea"
        },
        tuesday: {
            day: "Tuesday",
            special: "🥗 Pure Veg Day: Amritsari Rajma Chawal & Fresh Market Sabzi",
            lunch: "Amritsari Rajma Masala, Seasonal Aloo Gobi, Steamed Basmati Rice, 4 Soft Phulkas, Green Salad",
            dinner: "Homestyle Baingan Bharta / Chana Masala, Moong Dal Tadka, Pulao Rice, 4 Phulkas, Papad & Pickle",
            snack: "Samosa & Desi Chai"
        },
        wednesday: {
            day: "Wednesday",
            special: "🍗 Chicken Day #1 (Non-Veg) • 🧀 Paneer Day #1 (Pure Veg)",
            lunch: "Punjabi Kadhi Pakora, Jeera Aloo, Steamed Rice, 4 Tawa Phulkas, Onion Salad",
            dinner: "Non-Veg: Desi Dhaba Style Chicken Curry | Pure Veg: Shahi Kadhai Paneer, Dal Fry, Peas Pulao, 4 Butter Phulkas, Sweet Sewaiyan",
            snack: "Veg Cutlet & Sauce"
        },
        thursday: {
            day: "Thursday",
            special: "🥦 Fresh Market Sabzi: Pindi Chole & Kashmiri Dum Aloo",
            lunch: "Pindi Chole, Kashmiri Dum Aloo, Fragrant Jeera Rice, 4 Phulkas, Sirka Onion & Lemon",
            dinner: "Homestyle Bhindi Masala / Lauki Kofta, Dal Makhani, Steamed Rice, 4 Phulkas, Cucumber Raita, Kheer",
            snack: "Poha with crunchy peanuts"
        },
        friday: {
            day: "Friday",
            special: "🍗 Chicken Day #2 (Non-Veg) • 🥦 Fresh Aloo Shimla Mirch (Pure Veg)",
            lunch: "Panchmel Dal, Seasonal Bhindi Masala, Steamed Rice, 4 Phulkas, Kachumber Salad",
            dinner: "Non-Veg: Amritsari Tariwala Chicken Curry | Pure Veg: Aloo Shimla Mirch / Baingan Masala, Dal Maharani, Jeera Rice, 4 Butter Phulkas, Raita, Rasgulla",
            snack: "Aloo Tikki Chaat"
        },
        saturday: {
            day: "Saturday",
            special: "🐟 1 Din Fish ya Paneer (Non-Veg) • 🥦 Market Soya Chaap & Dal (Pure Veg)",
            lunch: "Tawa Soya Chaap Gravy, Dal Tadka, Steamed Rice, 4 Soft Phulkas, Salad",
            dinner: "Non-Veg: Amritsari Fish Curry OR Kadhai Paneer | Pure Veg: Seasonal Mix Sabzi / Kofta, Amritsari Dal, Jeera Pulao, 4 Butter Phulkas, Sweet Halwa",
            snack: "French Fries / Masala Maggi"
        },
        sunday: {
            day: "Sunday",
            special: "🍗 Chicken Day #3 Feast (Non-Veg) • 🧀 Paneer Day #2 Feast (Pure Veg)",
            lunch: "Special Dum Biryani with Raita / Chole Bhature Combo with Pickle & Chutney",
            dinner: "Non-Veg: Delhi Style Butter Chicken | Pure Veg: Rich Paneer Butter Masala, Dal Makhani, 4 Ghee Phulkas or 2 Laccha Parathas, Jeera Rice, Hot Gulab Jamun",
            snack: "Tea & Pakoras"
        }
    },

    reviews: [
        {
            name: "Harshit Verma",
            role: "B.Tech CSE (3rd Year)",
            hostel: "Law Gate, Khalsa Street PG",
            rating: 5,
            comment: "Taking Rasooi's 1-Time A Day Veg monthly subscription (₹2,599 for Dinner) was the best decision. Zero cooking headache, pure desi ghee phulkas, and fresh dal delivered right to my PG floor.",
            avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
        },
        {
            name: "Rohit Deshmukh",
            role: "B.Tech ME (4th Year)",
            hostel: "Green Valley, Block B Flat",
            rating: 5,
            comment: "Subscribed to the Non-Veg monthly plan for ₹2,999. Tariwala chicken and egg curry twice a week delivered hot without paying crazy Zomato fees. Fooding made genuinely easy.",
            avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
        },
        {
            name: "Simran Kaur",
            role: "MBA (1st Year)",
            hostel: "Hardaspur, Sunshine Girls PG",
            rating: 5,
            comment: "Living in Hardaspur, having a guaranteed monthly tiffin delivery is a lifesaver. Whenever I go home for the weekend, I just WhatsApp 9707889516 to pause my subscription and save my days.",
            avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80"
        },
        {
            name: "Karthik Nair",
            role: "B.Des Multimedia",
            hostel: "Law Gate, Main Market PG",
            rating: 5,
            comment: "Cleanest food around Law Gate. The 7-day rotating menu keeps it interesting. Pure desi ghee and no soda. Monthly subscription is worth every rupee.",
            avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
        }
    ],

    faqs: [
        {
            q: "How does the Rasooi Monthly Subscription model work?",
            a: "Rasooi is a monthly subscription-based service (no one-off daily ordering). You subscribe to a 30-day plan (e.g. 1-Time Daily Veg @ ₹2,599 or Non-Veg @ ₹2,999). Every day for 30 days, your fresh meal is delivered directly to your PG / Flat door in Law Gate, Green Valley, or Hardaspur."
        },
        {
            q: "Can I choose between Lunch and Dinner in the 1-Time Plan?",
            a: "Yes! In the 1-Time Daily plan, you can choose whether you want Lunch (12:30 PM - 2:00 PM) or Dinner (8:00 PM - 9:00 PM). You can even switch between lunch and dinner on specific days with a 2-hour advance WhatsApp notice."
        },
        {
            q: "Is there a tiffin security deposit for first-time users?",
            a: "Yes. For first-time subscribers, a one-time security fee of ₹1,000 applies for the insulated stainless-steel tiffin containers. This deposit is 100% refundable immediately when you conclude your subscription and return the tiffin boxes."
        },
        {
            q: "What happens if I go home for holidays or exams?",
            a: "All 30-day monthly plans include up to 4 pauses (and 6 pauses on full board). Simply message our WhatsApp at 9707889516 before 10:00 AM on the day you wish to pause, and your remaining subscription days will roll forward automatically."
        },
        {
            q: "Where do you deliver?",
            a: "We deliver exclusively to all off-campus student accommodation areas: Law Gate (Main Market, Khalsa St, Gate 1, all street PGs), Green Valley (Colony Blocks A & B, Main Road Flats), Hardaspur (Village & Student PG Enclaves), and nearby Maheru & Deep Nagar PGs. We do not deliver inside LPU campus hostels."
        },
        {
            q: "How do I subscribe or renew?",
            a: "Select your plan on the website or message us directly on WhatsApp at +91 97078 89516. We accept UPI (GPay, PhonePe, Paytm) and Cash on the first delivery day."
        }
    ],

    coupons: {
        "RASOOI100": { flatDiscount: 100, minAmount: 2500, desc: "₹100 Off on Monthly Tiffin Plans" },
        "TIFFIN150": { flatDiscount: 150, minAmount: 2800, desc: "₹150 Off on Non-Veg & Full Board Plans" }
    }
};

if (typeof window !== 'undefined') {
    window.LPU_DATA = LPU_DATA;
}
